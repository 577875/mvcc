package com.cognizant.bookmyseat.validator;

public class PassengerDetailsValidator {

}
