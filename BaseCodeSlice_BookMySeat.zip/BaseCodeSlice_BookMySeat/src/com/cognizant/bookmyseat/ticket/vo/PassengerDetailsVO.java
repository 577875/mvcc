package com.cognizant.bookmyseat.ticket.vo;

import java.util.Date;

public class PassengerDetailsVO {

	private String name;
	private long phoneNumber;
	private Date doj;
	private String source;
	private String destination;
	private String gender;
	private long cardNumber;
	private int pinNumber;
	private boolean isAgreed;

	/**
	 * @return String
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return long
	 */
	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @return
	 */
	public Date getDoj() {
		return doj;
	}

	/**
	 * @param doj
	 */
	public void setDoj(Date doj) {
		this.doj = doj;
	}

	/**
	 * @return String
	 */
	public String getSource() {
		return source;
	}

	/**
	 * @param source
	 */
	public void setSource(String source) {
		this.source = source;
	}

	/**
	 * @return String
	 */
	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	/**
	 * @return String
	 */
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return long
	 */
	public long getCardNumber() {
		return cardNumber;
	}

	/**
	 * @param cardNumber
	 */
	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}

	/**
	 * @return int
	 */
	public int getPinNumber() {
		return pinNumber;
	}

	/**
	 * @param pinNumber
	 */
	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}

	/**
	 * @return boolean
	 */
	public boolean getIsAgreed() {
		return isAgreed;
	}

	/**
	 * @param isAgreed
	 */
	public void setIsAgreed(boolean isAgreed) {
		this.isAgreed = isAgreed;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PassengerDetailsVO [name=");
		builder.append(name);
		builder.append(", phoneNumber=");
		builder.append(phoneNumber);
		builder.append(", doj=");
		builder.append(doj);
		builder.append(", source=");
		builder.append(source);
		builder.append(", destination=");
		builder.append(destination);
		builder.append(", gender=");
		builder.append(gender);
		builder.append(", cardNumber=");
		builder.append(cardNumber);
		builder.append(", pinNumber=");
		builder.append(pinNumber);
		builder.append(", isAgreed=");
		builder.append(isAgreed);
		builder.append("]");
		return builder.toString();
	}

}
