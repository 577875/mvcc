package com.cognizant.bookmyseat.controller;

import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.bookmyseat.login.vo.UserDetailsVO;

public class LoginController {

	// Add appropriate annotations and code wherever applicable
	/**
	 * @return ModelAndView
	 */
	public ModelAndView goToLogin() {
		ModelAndView model = new ModelAndView();
		model.setViewName("login");

		return model;
	}

	// Add appropriate annotations and code wherever required
	/**
	 * @param user
	 * @param model
	 * @return String
	 */
	public String submitLogin(UserDetailsVO user, Model model) {

		// Implement code here
		return "login";
	}

}
