package com.cognizant.bookmyseat.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.bookmyseat.ticket.vo.PassengerDetailsVO;

public class BookingController {

	// Add appropriate annotations and code wherever required
	/**
	 * @param res
	 * @param req
	 * @return ModelAndView
	 */
	public ModelAndView bookTicket(HttpServletResponse res,
			HttpServletRequest req) {
		ModelAndView model = new ModelAndView();

		return model;
	}

	// Add appropriate annotations wherever required
	/**
	 * @param pass
	 * @param result
	 * @return ModelAndView
	 */
	public ModelAndView submitBook(PassengerDetailsVO pass, BindingResult result) {
		ModelAndView model = new ModelAndView();

		model.setViewName("bookSuccess");
		return model;
	}

	// Add appropriate annotations here
	/**
	 * @return Map
	 */
	public Map<String, String> getCities() {
		Map<String, String> map = new HashMap<String, String>();

		map.put("Bengaluru", "Bengaluru");
		map.put("Chennai", "Chennai");
		map.put("Mumbai", "Mumbai");

		return map;
	}

	// Add appropriate annotations here
	/**
	 * @return Map
	 */
	public Map<String, String> getGernders() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("Male", "Male");
		map.put("Female", "Female");

		return map;
	}

}
